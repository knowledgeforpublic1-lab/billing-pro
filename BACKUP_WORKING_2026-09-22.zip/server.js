// Local dev server:  node server.js  ->  http://localhost:3000
// (Vercel deploy par api/index.js serverless function ki tarah chalta hai)
require('dotenv').config();
const express = require('express');
const path = require('path');
const apiApp = require('./api/index.js');

const app = express();

// API routes (/api/billing) — helmet/rate-limit/auth api/index.js ke andar.
// IMPORTANT: apiApp ko sirf /api/* par chalao. Poore app par lagane se helmet ka
// CSP (script-src 'self') index.html par bhi lag jata hai aur Vue CDN + inline
// script block ho jata hai — page raw {{ }} dikhata hai. (Vercel par static
// helmet ke bina serve hota hai, isliye wahan chalta tha.)
app.use((req, res, next) => {
  if (req.path === '/api' || req.path.startsWith('/api/')) return apiApp(req, res, next);
  next();
});

// Static frontend — poora folder serve MAT karo (xlsx/json/pdf/env leak hote hain).
// Sirf index.html serve karo; sensitive extensions/data files hard-block.
app.get(/^\/(?!api\/).*\.(xlsx|xls|json|pdf|txt|bat|env)$/i, (req, res) => res.status(403).send('Forbidden'));
app.get(['/', '/index.html'], (req, res) => res.sendFile(path.join(__dirname, 'index.html')));
// Alag mobile page — desktop index.html ko haath lagaye bina
app.get(['/mobile', '/mobile.html'], (req, res) => res.sendFile(path.join(__dirname, 'mobile.html')));
// Alag-alag asset files (style.css, aage app.js) — sirf safe naam, poora folder nahi
app.get('/style.css', (req, res) => res.sendFile(path.join(__dirname, 'style.css')));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Billing Pro local: http://localhost:${PORT}`));
